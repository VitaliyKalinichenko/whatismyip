(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/dd92d_modules_next-intl_dist_esm_development_shared_NextIntlClientProvider_18c0091d.js"
],
    source: "dynamic"
});
