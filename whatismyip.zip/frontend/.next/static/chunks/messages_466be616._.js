(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/messages/ar.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_ar_json_302269bf._.js",
  "static/chunks/messages_ar_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/ar.json (json)");
    });
});
}}),
"[project]/messages/de.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_de_json_27eeb0f4._.js",
  "static/chunks/messages_de_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/de.json (json)");
    });
});
}}),
"[project]/messages/en.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_en_json_672c7eaf._.js",
  "static/chunks/messages_en_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/en.json (json)");
    });
});
}}),
"[project]/messages/es.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_es_json_cf6e55aa._.js",
  "static/chunks/messages_es_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/es.json (json)");
    });
});
}}),
"[project]/messages/fr.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_fr_json_37e89458._.js",
  "static/chunks/messages_fr_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/fr.json (json)");
    });
});
}}),
"[project]/messages/hi.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_hi_json_c6023bda._.js",
  "static/chunks/messages_hi_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/hi.json (json)");
    });
});
}}),
"[project]/messages/pt.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_pt_json_c49b9155._.js",
  "static/chunks/messages_pt_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/pt.json (json)");
    });
});
}}),
"[project]/messages/uk.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_uk_json_1b541cbb._.js",
  "static/chunks/messages_uk_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/uk.json (json)");
    });
});
}}),
"[project]/messages/zh.json (json, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/messages_zh_json_e7318e62._.js",
  "static/chunks/messages_zh_json_b0fe4e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/messages/zh.json (json)");
    });
});
}}),
}]);