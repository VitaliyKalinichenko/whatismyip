(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/instrumentation.client.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// app/instrumentation.client.ts
__turbopack_context__.s({
    "disablePostHog": (()=>disablePostHog),
    "initializePostHog": (()=>initializePostHog)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$posthog$2d$js$2f$dist$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/posthog-js/dist/module.js [app-client] (ecmascript)");
;
// Initialize PostHog only after consent is given
let posthogInitialized = false;
function initializePostHog() {
    if (posthogInitialized) return;
    const consent = localStorage.getItem('cookie-consent');
    if (consent) {
        const preferences = JSON.parse(consent);
        if (preferences.analytics) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$posthog$2d$js$2f$dist$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].init(("TURBOPACK compile-time value", "phc_sFx8cMfrzUtl7rLSmgeAy6VB4Bv0E5QlUeD4mr5Br"), {
                api_host: ("TURBOPACK compile-time value", "https://eu.i.posthog.com"),
                capture_pageview: true,
                debug: false,
                opt_out_capturing_by_default: true
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$posthog$2d$js$2f$dist$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].opt_in_capturing(); // Enable capturing after consent
            posthogInitialized = true;
        }
    }
}
function disablePostHog() {
    if (posthogInitialized) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$posthog$2d$js$2f$dist$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].opt_out_capturing();
    }
}
// Check for existing consent on load
if ("TURBOPACK compile-time truthy", 1) {
    const consent = localStorage.getItem('cookie-consent');
    if (consent) {
        const preferences = JSON.parse(consent);
        if (preferences.analytics) {
            initializePostHog();
        }
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_instrumentation_client_ts_ab11bb30._.js.map