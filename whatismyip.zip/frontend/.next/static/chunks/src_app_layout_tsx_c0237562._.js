(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_652f4238._.js",
  "static/chunks/node_modules_b7d4d99d._.js",
  "static/chunks/_c5b61963._.js",
  "static/chunks/src_app_globals_b805903d.css"
],
    source: "dynamic"
});
