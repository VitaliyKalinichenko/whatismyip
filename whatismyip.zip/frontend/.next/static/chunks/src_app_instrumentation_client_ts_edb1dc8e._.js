(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_posthog-js_dist_module_5ff461f7.js",
  "static/chunks/src_app_instrumentation_client_ts_ab11bb30._.js"
],
    source: "dynamic"
});
