(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_ebee6351._.js",
  "static/chunks/node_modules_40c91d9e._.js"
],
    source: "dynamic"
});
